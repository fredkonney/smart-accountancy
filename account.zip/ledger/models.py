from django.db import models

# Create your models here.
class Employee(models.Model):
    employee_id = models.PositiveIntegerField(unique=True)
    name = models.CharField(max_length=255)
    job_title = models.CharField(max_length=255)
    email = models.EmailField()
    phone_number = models.CharField(max_length=20)
    salary = models.DecimalField(max_digits=10, decimal_places=2)
    address = models.CharField(max_length=255)
    gender = models.CharField(max_length=10)
    images = models.URLField()

    def __str__(self):
        return self.name
    

class AccountType(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class Account(models.Model):
    name = models.CharField(max_length=255)
    account_type = models.ForeignKey(AccountType, on_delete=models.CASCADE)
    account_subtype = models.ForeignKey('AccountSubType', null=True, blank=True, on_delete=models.CASCADE, related_name='accounts')
    balance = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    value = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    def __str__(self):
        return f'{self.name} - {abs(self.balance)}'
    

class AccountSubType(models.Model):
    account_type = models.ForeignKey(AccountType, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

    

class Transaction(models.Model):
    date = models.DateField()
    reference_number = models.CharField(max_length=50, blank=True, null=True)
    description = models.CharField(max_length=255)
    enable_balance_check = models.BooleanField(default=False)

    def __str__(self):
        return f'Transaction on {self.date}'

class Entry(models.Model):
    transaction = models.ForeignKey(Transaction, on_delete=models.CASCADE)
    account = models.ForeignKey(Account, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    is_debit = models.BooleanField(default=True)

    def __str__(self):
        return f'{self.account} - {self.amount}'

    def save(self, *args, **kwargs):
        self.amount = abs(self.amount)  # Convert the amount to its absolute value
        super().save(*args, **kwargs)
        self.update_account_balance()

    def delete(self, *args, **kwargs):
        self.update_account_balance()
        super().delete(*args, **kwargs)

    def update_account_balance(self):
        if self.is_debit:
            self.account.balance += abs(self.amount)
        else:
            self.account.balance -= abs(self.amount)
        self.account.balance = abs(self.account.balance)  # Convert the account balance to its absolute value
        self.account.save()



class JournalEntry(models.Model):
    date = models.DateField()
    reference_number = models.CharField(max_length=50, blank=True, null=True)
    description = models.CharField(max_length=255)

    def __str__(self):
        return f'Journal Entry on {self.date}'

class JournalEntryItem(models.Model):
    journal_entry = models.ForeignKey(JournalEntry, on_delete=models.CASCADE)
    account = models.ForeignKey(Account, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    is_debit = models.BooleanField(default=True)

    def __str__(self):
        return f'{self.account} - {self.amount}'
    


class AccountingRatio(models.Model):
    name = models.CharField(max_length=255, default='')    
    formula = models.TextField()
    balance = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    kind = models.CharField(max_length=60, blank=True)
    favourable_interpretation = models.CharField(max_length=255, null=True, default='',blank=True)
    less_favourable_interpretation = models.CharField(max_length=255, null=True, default='',blank=True)
    unfavourable_interpretation = models.CharField(max_length=255, null=True, default='',blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def calculate_ratio(self, data):
        # Example: calculate ROCE
        if self.name == 'ROCE':
            pbit = data.get('PBIT')
            capital_employed = data.get('Capital Employed')

            if pbit is None or capital_employed is None:
                return None

            ratio_value = (pbit / capital_employed) * 100
            return ratio_value

        
        # Example: calculate ROE
        if self.name == 'ROE':
            profit_after_tax = data.get('Profit After Tax')
            total_equity = data.get('Total Equity')
            ratio_value = (profit_after_tax / total_equity) * 100
            return ratio_value

        # Example: calculate Operating profit margin
        if self.name == 'Operating Profit Margin':
            pbit = data.get('PBIT')
            revenue = data.get('Revenue')
            ratio_value = (pbit / revenue) * 100
            return ratio_value

        # Example: calculate Asset turnover
        if self.name == 'Asset Turnover':
            revenue = data.get('Revenue')
            capital_employed = data.get('Capital Employed')
            ratio_value = revenue // capital_employed
            return ratio_value

        '''# Example: calculate Gross margin
        if self.name == 'Gross Margin':
            gross_profit = data['Gross Profit']
            revenue = data['Revenue']
            ratio_value = (gross_profit // revenue) * 100
            return ratio_value

        # Example: calculate Current ratio
        if self.name == 'Current Ratio':
            current_assets = data['Current Assets']
            current_liabilities = data['Current Liabilities']
            ratio_value = current_assets / current_liabilities
            return ratio_value

        # Example: calculate Quick ratio
        if self.name == 'Quick Ratio':
            current_assets = data['Current Assets']
            inventory = data['Inventory']
            current_liabilities = data['Current Liabilities']
            ratio_value = (current_assets - inventory) / current_liabilities
            return ratio_value

        # Example: calculate Receivables collection period
        if self.name == 'Receivables Collection Period':
            receivables = data['Receivables']
            credit_sales = data['Credit Sales']
            ratio_value = (receivables / credit_sales) * 365
            return ratio_value

        # Example: calculate Inventory holding period
        if self.name == 'Inventory Holding Period':
            inventory = data['Inventory']
            cost_of_sales = data['Cost of Sales']
            ratio_value = (inventory / cost_of_sales) * 365
            return ratio_value

        # Example: calculate Payables payment period
        if self.name == 'Payables Payment Period':
            payables = data['Payables']
            credit_purchases = data['Credit Purchases']
            ratio_value = (payables / credit_purchases) * 365
            return ratio_value

        # Example: calculate Debt to equity ratio
      
        if self.name == 'Debt to Debt + Equity Ratio':
            non_current_liabilities = data['Non-Current Liabilities']
            total_equity = data['Total Equity']
            ratio_value = (non_current_liabilities / (total_equity + non_current_liabilities)) * 100
            return ratio_value

        # Example: calculate Interest cover
        if self.name == 'Interest Cover':
            operating_profit = data['Operating Profit']
            finance_costs = data['Finance Costs']
            ratio_value = operating_profit / finance_costs
            return ratio_value'''

        # Add more formulas for other ratios as needed

        # Return None if the ratio is not recognized
        return None
    def get_interpretation(self, ratio_value):
        if ratio_value is None:
            return 'N/A'  # or any other default value you prefer

        if self.name == 'ROCE':
            if ratio_value > 25:
                return self.favourable_interpretation
            elif 15 < ratio_value <= 25:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation
            
        if self.name == 'ROE':
            if ratio_value > 15:
                return self.favourable_interpretation
            elif 5 < ratio_value <= 15:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation

        if self.name == 'Operating Profit Margin':
            if ratio_value > 30:
                return self.favourable_interpretation
            elif 10 < ratio_value <= 30:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation


        if self.name == 'Asset Turnover':
            if ratio_value > 2:
                return self.favourable_interpretation
            elif 1 < ratio_value <= 2:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation

        if self.name == 'Current Ratio':
            if ratio_value > 2:
                return self.favourable_interpretation
            elif ratio_value > 1:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation

        if self.name == 'Quick Ratio':
            if ratio_value > 1:
                return self.favourable_interpretation
            elif ratio_value > 0.5:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation

        if self.name == 'Receivables Collection Period':
            if ratio_value < 30:
                return self.favourable_interpretation
            elif ratio_value < 60:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation

        if self.name == 'Inventory Holding Period':
            if ratio_value < 60:
                return self.favourable_interpretation
            elif ratio_value < 90:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation

        if self.name == 'Payables Payment Period':
            if ratio_value < 45:
                return self.favourable_interpretation
            elif ratio_value < 75:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation

        if self.name == 'Debt to Equity Ratio':
            if ratio_value < 50:
                return self.favourable_interpretation
            elif ratio_value < 100:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation

        if self.name == 'Interest Cover':
            if ratio_value > 3:
                return self.favourable_interpretation
            elif ratio_value > 2:
                return self.less_favourable_interpretation
            else:
                return self.unfavourable_interpretation

        # Add more conditions for other ratios as needed

        return 'N/A'