from django.urls import path
from . import views

# Define URL patterns for the application
urlpatterns = [
    # Home page URL pattern
    path('', views.home, name='home'),
    path('employee/', views.employee, name='employee'),
    path('accounts/', views.chart_of_accounts, name='accounts'),
    path('trial-balance/', views.chart_of_accounts, name='trial_balance'),
    path('profit_and_loss/', views.profit_and_loss, name='profit_and_loss'),
    path('balance_sheet/', views.balance_sheet, name='balance_sheet'),
    path('chart/', views.chart_view, name='chart'),
    path('generate-chart/', views.chart_generation, name='generate_chart'),
    path('get-data-fields/', views.get_data_fields, name='get_data_fields'),
    path('ratio/', views.ratio_list, name='ratio'),   
    path('account_list/', views.account_list, name='account_list'),
    
]