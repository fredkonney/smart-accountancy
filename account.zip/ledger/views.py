from django.shortcuts import render
from django.core.exceptions import ObjectDoesNotExist
from .models import Employee,AccountType, AccountSubType, AccountingRatio
from .models import Account,JournalEntry, JournalEntryItem,Transaction, Entry
from django.db import models
from django.db.models import F, ExpressionWrapper, Func
# Create your views here.


def home(request):
    # Render the home page template
    return render(request, 'tennis_home2.html')


def employee(request):
    # Retrieve all tennis products from the database and pass them to the template
    mytennis_employee = Employee.objects.all().values()
    context = {
        'mytennis_employee': mytennis_employee,
    }
    return render(request, 'employee.html', context)





from django.db.models import Sum

def chart_of_accounts(request):
    # Retrieve all accounts
    accounts = Account.objects.all()

    # Initialize lists to store account balances for debit and credit sides
    debit_accounts_balance = []
    credit_accounts_balance = []

    # Variables to calculate total debit and credit amounts
    debit_total = 0
    credit_total = 0

    # Iterate over each account
    for account in accounts:
        # Calculate the debit and credit balances for the account
        entries = Entry.objects.filter(account=account)
        debit_balance = entries.filter(is_debit=True).aggregate(Sum('amount'))['amount__sum']
        debit_balance = abs(debit_balance) if debit_balance is not None else 0
        credit_balance = entries.filter(is_debit=False).aggregate(Sum('amount'))['amount__sum']
        credit_balance = abs(credit_balance) if credit_balance is not None else 0

        # Add the account to the debit or credit side based on the balance
        if debit_balance > credit_balance:
            debit_accounts_balance.append({'name': account.name, 'balance': debit_balance - credit_balance})
            debit_total += debit_balance - credit_balance
        else:
            credit_accounts_balance.append({'name': account.name, 'balance': credit_balance - debit_balance})
            credit_total += credit_balance - debit_balance

    # Render the template with the debit and credit account balances and totals
    return render(request, 'trial_balance.html', {
        'debit_accounts_balance': debit_accounts_balance,
        'credit_accounts_balance': credit_accounts_balance,
        'debit_total': debit_total,
        'credit_total': credit_total,
    })
def create_transaction(request):
    if request.method == 'POST':
        # Retrieve the selected accounts and transaction data from the request

        # Define your transaction data (date, description, and entries)
        transaction_data = {
            'date': request.POST.get('transaction_date'),
            'description': request.POST.get('transaction_description'),
            'enable_balance_check': request.POST.get('enable_balance_check') == 'on',
            'entries': [
                {'account': request.POST.get(f'account_{i}'), 'amount': abs(float(request.POST.get(f'amount_{i}'))), 'is_debit': bool(request.POST.get(f'is_debit_{i}'))}
                for i in range(1, int(request.POST.get('entry_count')) + 1)
            ]
        }

        # Create a transaction
        transaction = Transaction.objects.create(
            date=transaction_data['date'],
            description=transaction_data['description'],
            enable_balance_check=transaction_data['enable_balance_check']
        )

        # Create journal entry
        journal_entry = JournalEntry.objects.create(
            date=transaction_data['date'],
            description=transaction_data['description']
        )

        # Create entries for both transaction and journal entry
        entries_data = transaction_data['entries']
        total_debit = 0
        total_credit = 0

        for entry_data in entries_data:
            account = entry_data['account']
            amount = entry_data['amount']
            is_debit = entry_data['is_debit']
            Entry.objects.create(
                transaction=transaction,
                account=account,
                amount=amount,
                is_debit=is_debit
            )
            JournalEntryItem.objects.create(
                journal_entry=journal_entry,
                account=account,
                amount=amount,
                is_debit=is_debit
            )

            if is_debit:
                total_debit += amount
            else:
                total_credit += amount  # Add credit amount instead of subtracting it

        # Perform balance validation if enabled
        if transaction.enable_balance_check and total_debit != total_credit:
            return render(request, 'create_transaction_form.html', {'error_message': 'Debit and Credit amounts do not balance.'})

        return render(request, 'transaction_created.html')
    else:
        # Handle GET request for rendering the form or transaction creation page
        # You can render the form template or redirect to another appropriate page
        return render(request, 'create_transaction_form.html')

def calculate_net_profit():
    revenue_type = AccountType.objects.get(name='Revenue')
    cogs_type = AccountType.objects.get(name='Cost of Goods Sold')
    expense_type = AccountType.objects.get(name='Expense')
    ratio_type = AccountType.objects.get(name='Ratio')
    interest_subtype_name = 'Interests'
    tax_subtype_name = 'Taxes'

    revenue_accounts = Account.objects.filter(account_type=revenue_type)
    cogs_accounts = Account.objects.filter(account_type=cogs_type)
    expense_accounts = Account.objects.filter(account_type=expense_type)

    try:
        interest_subtype = AccountSubType.objects.get(name=interest_subtype_name)
        interest_accounts = Account.objects.filter(account_subtype=interest_subtype)
    except ObjectDoesNotExist:
        interest_accounts = []

    try:
        tax_subtype = AccountSubType.objects.get(name=tax_subtype_name)
        tax_accounts = Account.objects.filter(account_subtype=tax_subtype)
    except ObjectDoesNotExist:
        tax_accounts = []

    # Retrieve all expense accounts excluding interests and taxes
    expenses_without_interest_tax = expense_accounts.exclude(account_subtype__in=[interest_subtype, tax_subtype])

    revenue_total = abs(revenue_accounts.aggregate(total=Sum('balance'))['total'] or 0)
    cogs_total = abs(cogs_accounts.aggregate(total=Sum('balance'))['total'] or 0)
    expense_total = abs(expenses_without_interest_tax.aggregate(total=Sum('balance'))['total'] or 0)
    interest_total = abs(interest_accounts.aggregate(total=Sum('balance'))['total'] or 0)
    tax_total = abs(tax_accounts.aggregate(total=Sum('balance'))['total'] or 0)

    gross_profit = revenue_total - cogs_total
    pbit = gross_profit - expense_total
    profit_after_tax = pbit - (interest_total + tax_total)

    net_profit_account, _ = Account.objects.get_or_create(name='Profit After Tax', account_type=ratio_type)
    net_profit_account.balance = profit_after_tax
    net_profit_account.save()

    return profit_after_tax


def profit_and_loss(request):
    revenue_type = AccountType.objects.get(name='Revenue')
    cogs_type = AccountType.objects.get(name='Cost of Goods Sold')
    expense_type = AccountType.objects.get(name='Expense')
    interest_subtype_name = 'Interests'
    tax_subtype_name = 'Taxes'

    revenue_accounts = Account.objects.filter(account_type=revenue_type)
    cogs_accounts = Account.objects.filter(account_type=cogs_type)
    expense_accounts = Account.objects.filter(account_type=expense_type)

    try:
        interest_subtype = AccountSubType.objects.get(name=interest_subtype_name)
        interest_accounts = Account.objects.filter(account_subtype=interest_subtype)
    except ObjectDoesNotExist:
        interest_accounts = []

    try:
        tax_subtype = AccountSubType.objects.get(name=tax_subtype_name)
        tax_accounts = Account.objects.filter(account_subtype=tax_subtype)
    except ObjectDoesNotExist:
        tax_accounts = []

    expenses_without_interest_tax = expense_accounts.exclude(account_subtype__in=[interest_subtype, tax_subtype])
    revenue_total = revenue_accounts.aggregate(total=Sum('balance')).get('total', 0) or 0
    cogs_total = cogs_accounts.aggregate(total=Sum('balance')).get('total', 0) or 0
    expense_total = expenses_without_interest_tax.aggregate(total=Sum('balance')).get('total', 0) or 0
    interest_total = interest_accounts.aggregate(total=Sum('balance')).get('total', 0) or 0
    tax_total = tax_accounts.aggregate(total=Sum('balance')).get('total', 0) or 0

    revenue_total = abs(revenue_total)
    cogs_total = abs(cogs_total)
    expense_total = abs(expense_total)
    interest_total = abs(interest_total)
    tax_total = abs(tax_total)

    gross_profit = revenue_total - cogs_total
    pbit = revenue_total - cogs_total - expense_total
    profit_after_tax = pbit - (interest_total + tax_total)

    net_profit_account = Account.objects.get(name='Net Profit')
    net_profit_account.balance = profit_after_tax
    net_profit_account.save()

    return render(request, 'profit_and_loss.html', {
        'revenue_accounts_balance': revenue_accounts,
        'cogs_accounts_balance': cogs_accounts,
        'expense_accounts_balance': expense_accounts,
        'interest_accounts_balance': interest_accounts,
        'tax_accounts_balance': tax_accounts,
        'revenue_total': revenue_total,
        'cogs_total': cogs_total,
        'expense_total': expense_total,
        'interest_total': interest_total,
        'tax_total': tax_total,
        'gross_profit': gross_profit,
        'pbit': pbit,
        'profit_after_tax': profit_after_tax,
        'expenses_without_interest_tax': expenses_without_interest_tax
    })
from django.db.models import F, ExpressionWrapper, Func

from django.db.models import F, ExpressionWrapper, Func, Sum
from django.shortcuts import render
from .models import Account, AccountSubType


from django.db.models import F, ExpressionWrapper, Func, Sum
from django.shortcuts import render
from .models import Account, AccountSubType


def balance_sheet(request):
    # Retrieve asset accounts
    asset_accounts = Account.objects.filter(account_type__name='Asset')

    # Calculate the total asset balance
    total_assets = abs(asset_accounts.aggregate(total=Sum('balance'))['total'] or 0)

    # Retrieve liability accounts
    liability_accounts = Account.objects.filter(account_type__name='Liability')

    # Calculate the total liability balance
    total_liabilities = abs(liability_accounts.aggregate(total=Sum('balance'))['total'] or 0)

    # Retrieve equity accounts
    equity_accounts = Account.objects.filter(account_type__name='Equity')
    equity_accounts_abs = []

    # Function to recursively fetch sub-accounts
    def get_sub_accounts(account):
        """
        Recursive function to retrieve all sub-accounts of an account.
        """
        sub_accounts = []
        sub_types = AccountSubType.objects.filter(account_type=account.account_type)
        for sub_type in sub_types:
            sub_account = Account.objects.filter(parent=account, account_subtype=sub_type).first()
            if sub_account:
                sub_accounts.append(sub_account)
                sub_accounts += get_sub_accounts(sub_account)
        return sub_accounts

    # Iterate over equity accounts and fetch sub-accounts
    for account in equity_accounts:
        equity_accounts_abs.append({
            'name': account.name,
            'balance': abs(account.balance)
        })
        equity_accounts_abs += get_sub_accounts(account)

    # Calculate the total equity balance
    total_equity = sum(account['balance'] for account in equity_accounts_abs)

    # Calculate net assets
    capital_employed = total_assets - total_liabilities
    total_assets_liabilities = total_assets - total_liabilities

    # Calculate the net profit
    net_profit = abs(calculate_net_profit())
    liability_accounts_abs = list(liability_accounts.values('name', account_balance=ExpressionWrapper(Func(F('balance'), function='ABS'), output_field=models.DecimalField())))

    # Add net profit to the list of equity accounts as a dictionary
    equity_accounts_abs.append({
        'name': 'Profit After Tax',
        'balance': net_profit,
    })
    # Recalculate total equity
    total_equity += net_profit

    # Retrieve all accounts and account subtypes
    sub_accounts = Account.objects.select_related('account_subtype').all()

    # Retrieve sub-accounts by category
    fixed_assets = sub_accounts.filter(account_subtype__name='Fixed Assets')
    current_assets = sub_accounts.filter(account_subtype__name='Current Assets')
    long_term_liabilities = sub_accounts.filter(account_subtype__name='Long-term Liabilities')
    current_liabilities = sub_accounts.filter(account_subtype__name='Current Liabilities')

    # Calculate the total fixed assets
    total_fixed_assets = sum(account.balance for account in fixed_assets)

    # Calculate the total current assets
    total_current_assets = sum(account.balance for account in current_assets)

    # Calculate the total long-term liabilities
    total_long_term_liabilities = abs(sum(account.balance for account in long_term_liabilities))

    # Calculate the total current liabilities
    total_current_liabilities = abs(sum(account.balance for account in current_liabilities))

    # Retrieve or create the accounts and update their balances
    update_accounts({
        'total_fixed_assets': total_fixed_assets,
        'total_current_assets': total_current_assets,
        'total_long_term_liabilities': total_long_term_liabilities,
        'total_current_liabilities': total_current_liabilities,
        'total_liabilities_total_equity': total_liabilities + total_equity,
        'total_assets': total_assets,
        'total_liabilities': total_liabilities,
        'total_equity': total_equity,
        'capital_employed': capital_employed,
        'net_profit': net_profit,
        'total_assets_liabilities': total_assets_liabilities,
        'fixed_assets': fixed_assets,
        'current_assets': current_assets,
        'long_term_liabilities': long_term_liabilities,
        'current_liabilities': current_liabilities,
        'total_fixed_assets': total_fixed_assets,
        'total_current_assets': total_current_assets,
        'total_long_term_liabilities': total_long_term_liabilities,
        'total_current_liabilities': total_current_liabilities,
        'total_liabilities_total_equity': total_liabilities + total_equity,
    })

    return render(request, 'balance_sheet.html', {
        'asset_accounts': asset_accounts,
        'liability_accounts': liability_accounts_abs,
        'equity_accounts': equity_accounts_abs,
        'total_assets': total_assets,
        'total_liabilities': total_liabilities,
        'total_equity': total_equity,
        'capital_employed': capital_employed,
        'net_profit': net_profit,
        'total_assets_liabilities': total_assets_liabilities,
        'fixed_assets': fixed_assets,
        'current_assets': current_assets,
        'long_term_liabilities': long_term_liabilities,
        'current_liabilities': current_liabilities,
        'total_fixed_assets': total_fixed_assets,
        'total_current_assets': total_current_assets,
        'total_long_term_liabilities': total_long_term_liabilities,
        'total_current_liabilities': total_current_liabilities,
        'total_liabilities_total_equity': total_liabilities + total_equity,
    })
def update_accounts(data):
    ratio_type = AccountType.objects.get(name='Ratio')

    fixed_assets_account, _ = Account.objects.get_or_create(name='Fixed Assets', account_type=ratio_type)
    fixed_assets_account.balance = data['total_fixed_assets']
    fixed_assets_account.save()

    current_assets_account, _ = Account.objects.get_or_create(name='Current Assets', account_type=ratio_type)
    current_assets_account.balance = data['total_current_assets']
    current_assets_account.save()

    long_term_liabilities_account, _ = Account.objects.get_or_create(name='Long-term Liabilities', account_type=ratio_type)
    long_term_liabilities_account.balance = data['total_long_term_liabilities']
    long_term_liabilities_account.save()

    current_liabilities_account, _ = Account.objects.get_or_create(name='Current Liabilities', account_type=ratio_type)
    current_liabilities_account.balance = data['total_current_liabilities']
    current_liabilities_account.save()

    liabilities_equity_account, _ = Account.objects.get_or_create(name='Total Liabilities + Total Equity', account_type=ratio_type)
    liabilities_equity_account.balance = data['total_liabilities_total_equity']
    liabilities_equity_account.save()

    net_assets_account, _ = Account.objects.get_or_create(name='Capital Employed', account_type=ratio_type)
    net_assets_account.balance = data['capital_employed']
    net_assets_account.save()

    total_assets_account, _ = Account.objects.get_or_create(name='Total Assets', account_type=ratio_type)
    total_assets_account.balance = data['total_assets']
    total_assets_account.save()

    total_liabilities_account, _ = Account.objects.get_or_create(name='Total Liabilities', account_type=ratio_type)
    total_liabilities_account.balance = data['total_liabilities']
    total_liabilities_account.save()

    total_equity_account, _ = Account.objects.get_or_create(name='Total Equity', account_type=ratio_type)
    total_equity_account.balance = data['total_equity']
    total_equity_account.save()

    net_assets_account, _ = Account.objects.get_or_create(name='Capital Employed', account_type=ratio_type)
    net_assets_account.balance = data['Capital Employed']
    net_assets_account.save()

    net_profit_account, _ = Account.objects.get_or_create(name='PBIT', account_type=ratio_type)
    net_profit_account.balance = data['PBIT']
    net_profit_account.save()

    total_assets_liabilities_account, _ = Account.objects.get_or_create(name='Total Assets + Total Liabilities', account_type=ratio_type)
    total_assets_liabilities_account.balance = data['total_assets_liabilities']
    total_assets_liabilities_account.save()

def update_accounts(data):
    net_assets_account = Account.objects.get(name='Capital Employed')
    capital_employed = data.get('Capital Employed')
    if capital_employed is not None:
        net_assets_account.balance = capital_employed
        net_assets_account.save()    


def chart_view(request):
    return render(request, 'chart.html')



from django.db import connection
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json
from django.db import connection
from django.http import JsonResponse

def get_data_fields(request):
    table = request.GET.get('table')

    with connection.cursor() as cursor:
        cursor.execute(f"PRAGMA table_info({table})")
        fields = [field[1] for field in cursor.fetchall()]

    return JsonResponse({'fields': fields})


def get_table_names():
    with connection.cursor() as cursor:
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        table_names = [row[0] for row in cursor.fetchall()]
    return table_names

@csrf_exempt
def chart_generation(request):
    if request.method == 'POST':
        x_field = request.POST.get('x_field')
        y_field = request.POST.get('y_field')
        chart_type = request.POST.get('chart_type')
        table_name = request.POST.get('table_name')

        with connection.cursor() as cursor:
            cursor.execute(f"SELECT {x_field}, {y_field} FROM {table_name}")
            rows = cursor.fetchall()

        chart_data = {
            'labels': [row[0] for row in rows],
            'datasets': [{
                'label': y_field.capitalize(),
                'data': [row[1] for row in rows],
                'backgroundColor': 'rgba(75, 192, 192, 0.2)',
                'borderColor': 'rgba(75, 192, 192, 1)',
                'borderWidth': 1
            }]
        }

        if chart_type == 'bar':
            chart_data['chart_type'] = 'bar'

        return JsonResponse(chart_data)

    else:
        tables = get_table_names()
        return render(request, 'chart_generation.html', {'tables': tables})
    

import json

from django.db.models import F

def ratio_list(request):
    # Get all AccountingRatio objects
    ratios = AccountingRatio.objects.all()

    # Get the data needed for ratio calculation from the Account table
    account_data = Account.objects.filter(
        name__in=['PBIT', 'Capital Employed', 'Profit After Tax', 'Total Equity', 'Revenue']
    ).values('name', 'balance')

    # Prepare the data dictionary for ratio calculation
    data = {}
    for account in account_data:
        data[account['name']] = account['balance']

    # Calculate the ratios and get their interpretations
    ratio_data = []
    for ratio in ratios:
        ratio_value = ratio.calculate_ratio(data)
        kind = ratio.kind
        interpretation = ratio.get_interpretation(ratio_value)
        ratio_value_formatted = "{:.2f}".format(ratio_value) if ratio_value is not None else None
        ratio_data.append((ratio, ratio.formula, ratio_value_formatted, kind, interpretation))

    # Prepare the context dictionary for rendering the template
    context = {
        'ratios': ratio_data
    }

    # Render the template with the context and return the HttpResponse
    return render(request, 'ratio.html', context) 

    

def account_list(request):
    accounts = Account.objects.all()
    return render(request, 'account_list.html', {'accounts': accounts})