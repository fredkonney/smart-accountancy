from django.contrib import admin
from ledger.models import Employee
from .models import Transaction, Entry, AccountSubType, AccountingRatio
from .models import AccountType, Account,JournalEntry, JournalEntryItem
from django import forms
from django.core.exceptions import ValidationError
# Register your models here.
admin.site.register(Employee)



class EntryInline(admin.TabularInline):
    model = Entry
    extra = 1

class TransactionAdmin(admin.ModelAdmin):
    inlines = [EntryInline]
    list_display = ['date', 'description', 'reference_number']
    list_filter = ['date']
    search_fields = ['description']





class AccountAdmin(admin.ModelAdmin):
    list_display = ['name', 'account_type', 'balance']
    list_filter = ['account_type']
    search_fields = ['name']

class TransactionAdmin(admin.ModelAdmin):
    list_display = ['date', 'reference_number', 'description']
    list_filter = ['date']
    search_fields = ['description']

class JournalEntryAdmin(admin.ModelAdmin):
    list_display = ['date', 'reference_number', 'description']
    list_filter = ['date']
    search_fields = ['description']

admin.site.register(AccountType)
admin.site.register(AccountSubType)
admin.site.register(Account, AccountAdmin)
admin.site.register(AccountingRatio)
admin.site.register(Entry)
admin.site.register(JournalEntry, JournalEntryAdmin)
admin.site.register(JournalEntryItem)


from django.contrib import messages
from .models import Transaction, Entry, JournalEntry, JournalEntryItem
from .models import Transaction, Entry


class EntryInline(admin.TabularInline):
    model = Entry
    extra = 1


class TransactionAdmin(admin.ModelAdmin):
    inlines = [EntryInline]

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)

    def save_related(self, request, form, formsets, change):
        super().save_related(request, form, formsets, change)

        if form.instance.enable_balance_check:
            entries = form.instance.entry_set.all()
            total_debit = sum(entry.amount for entry in entries if entry.is_debit)
            total_credit = sum(entry.amount for entry in entries if not entry.is_debit)

            if total_debit != total_credit:
                raise ValidationError('Debit and Credit amounts do not balance.')


admin.site.register(Transaction, TransactionAdmin)
